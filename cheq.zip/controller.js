import { renderAllLists, showListDetails } from "./view.js";
import { List} from "./model.js";
import Person from "../JSteil/wen3/01_WhatsApp/js/person.js";
import Group from "../JSteil/wen3/01_WhatsApp/js/group.js";

let data = { lists: [] }; // Globale Variable für Listen

const myModal = document.getElementById('addListsModal')
const myInput = document.getElementById('addListsModal')

myModal.addEventListener('shown.bs.modal', () => {
    myInput.focus()
})

async function loadJsonData() {
    try {
        let listOfLists;
        fetch("json/lists.json")
            .then((response) => response.json())
            .then((data) => {
                console.log(data);
                this.id = data.id;
                for (let p of data.lists) {
                    let person = new Person(p);
                    this.#contactList.set(person.id, person);
                    this.#addMessageToContact(person, p, false);
                }
                for (let g of data.groups) {
                    let group = new Group(g);
                    this.#contactList.set(group.id, group); //.set weil es eine Map is, wenn Array wäre dann würde .push stehen
                    this.#addMessageToContact(group, g, true);
                    for (let memberId of g.members) {
                        if (memberId != this.#ownId) {
                            let c = this.#contactList.get(memberId);
                            if (c) {
                                group.addContact(c);
                                c.addGroup(group);
                            }
                        }
                    }
                }
                this.#printContactList();
            })
            .catch((err) => {
                console.log(err);
            })
        let response = await fetch("lists.json");
        data = await response.json();
    } catch (error) {
        console.error("Fehler beim Laden der JSON-Daten:", error);
        data = { lists: [] };
    }
}

document.addEventListener("DOMContentLoaded", async function() {
    await loadJsonData();
    renderAllLists(data.lists);
    attachListClickEvents(); // Events setzen
});

document.getElementById("createList").onclick = () => {
    let nameInput = document.querySelector("#listNameInput");
    let listName = nameInput.value.trim();
    console.log(listName);

    if (listName === "") {
        alert("Bitte einen Namen eingeben!");
    } else {
        let newList = new List({ id: Date.now(), name: listName });
        data.lists.push(newList);
        localStorage.setItem("Lists", JSON.stringify(data.lists));

        renderAllLists(data.lists);
        attachListClickEvents();
    }
};

function attachListClickEvents() {
    document.querySelectorAll(".list").forEach(listElement => {
        listElement.addEventListener("click", () => {
            document.querySelectorAll(".list").forEach(el => el.classList.remove("activeList"));
            listElement.classList.add("activeList");

            const listIndex = listElement.dataset.index;
            showListDetails(data.lists[listIndex]);
        });
    });
}

function createModal() {
    let modal = document.createElement("div");
    modal.innerHTML = `
        <div class="modal-wrapper">
            <div class="listCreation modal-container">
                <h2>Liste erstellen</h2>
                <label for="listNameInput">Name der Liste</label>
                <input type="text" id="listNameInput">
                    <div class="modal-btns">
                        <button id="closeModal" class="btn btn-danger">Schließen</button>
                        <button id="createList" class="btn btn-success">Liste erstellen</button>
                    </div>
            </div>
        </div>
`;

document.body.insertBefore(modal, document.body.firstChild);

document.getElementById("closeModal").onclick = () => modal.remove();


}