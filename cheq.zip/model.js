class List {
    #id;
    #name;
    #completed;
    #items;

    constructor({id, name}) {
        this.#id = id;
        this.#name = name;
        this.#items = [];
        this.#completed = false;
    }

    addItem(item) {
        this.#items.push(item);
    }

    removeItem(itemId) {
        this.#items = this.#items.filter(item => item.id !== itemId);
    }

    toggleCompleted() {
        this.#completed = !this.#completed;
    }

    getItems() {
        return this.#items;
    }

    getName (){
        return this.#name;
    }
}

class Item {
    #id;
    #name;
    #symbol;
    #tags;

    constructor({id, name, symbol}) {
        this.#id = id;
        this.#name = name;
        this.#symbol = symbol;
        this.#tags = [];
    }

    getName() {
        return this.#name;
    }

    addTag(tag) {
        this.#tags.push(tag);
    }

    removeTag(tagName) {
        this.#tags = this.#tags.filter(tag => tag.tagname !== tagName);
    }

    getTags() {
        return this.#tags;
    }
}

class ListItem {
    #itemId;
    #quantity;
    #completed;

    constructor(itemId, quantity = 1, completed = false) {
        this.#itemId = itemId;
        this.#quantity = quantity;
        this.#completed = completed;
    }

    getItemId() {
        return this.#itemId;
    }

    getQuantity() {
        return this.#quantity;
    }

    setQuantity(quantity) {
        this.#quantity = quantity;
    }

    toggleCompleted() {
        this.#completed = !this.#completed;
    }

    isCompleted() {
        return this.#completed;
    }
}

class Tag {
    #tagname;

    constructor({tagname}) {
        this.#tagname = tagname;
    }

    getTagName() {
        return this.#tagname;
    }
}

class User {
    #username;
    #userid;
    #userStatus;
    #lists;

    constructor({username, userid, userStatus = 0}) {
        this.#userid = userid;
        this.#userStatus = userStatus;
        this.#username = username;
        this.#lists = [];
    }

    addList(list) {
        this.#lists.push(list);
    }

    removeList(listId) {
        this.#lists = this.#lists.filter(list => list.id !== listId);
    }

    getLists() {
        return this.#lists;
    }
}

export { List, Item, ListItem, Tag, User };